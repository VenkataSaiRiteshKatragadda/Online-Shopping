package com.example.onlineshoping;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    Spinner Sproduct;
    ImageView img;
    EditText txtQty;
    TextView priceTv, totalTv;
    RadioButton pickRb, deliveryRb;
    Button orderBtn;

    //the array of product names
    String products[]={"Alcohol","Gloves","Mask","Sanitizer"};
    double prices[]={13.9,23.5,34,17.5};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Sproduct=findViewById(R.id.spinner);
        img=findViewById(R.id.imageView);
        txtQty=findViewById(R.id.txtQuant);
        priceTv=findViewById(R.id.tvPrice);
        totalTv=findViewById(R.id.tvTotal);
        pickRb=findViewById(R.id.rbPick);
        deliveryRb=findViewById(R.id.rbDelivery);
        orderBtn=findViewById(R.id.btnOrder);

        //To assign the array products as data source fot the spinner
        ArrayAdapter aa= new ArrayAdapter(this,android.R.layout.simple_spinner_item,products);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Sproduct.setAdapter(aa);

        //events sources
        orderBtn.setOnClickListener(this);

        Sproduct.setOnItemSelectedListener(this);
    }
    @Override
    public void onClick(View view) {
        double total=0;
        int qty=0;
        if(!txtQty.getText().toString().equals(""))
            qty = Integer.parseInt(txtQty.getText().toString());
        else
            Toast.makeText(getApplicationContext(),"Please enter the quantity",Toast.LENGTH_LONG).show();
        total = Double.parseDouble(priceTv.getText().toString()) * qty;
        if (deliveryRb.isChecked() && total<100)
            total *=1.1; //add 10% to the total . total = total + total*0.1
        total*=1.13; //add 13% to the total as a tax .total = total + total * 0.13
        String amount = String.format("%.2f",total);
        totalTv.setText(amount);

    }



    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String price=String.format("%.2f",prices[i]);
        priceTv.setText(price);
        String imgName = products[i].toLowerCase();
        int imgId = getResources().getIdentifier(imgName,"drawable",getPackageName());
        img.setImageResource(imgId);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {


    }
}
